from django.db import models

# Create your models here.
class Admin(models.Model):
    name = models.CharField(max_length=40)
    email = models.CharField(max_length=40)
    pass_field = models.CharField(db_column='pass', max_length=20)  # Field renamed because it was a Python reserved word.

    class Meta:
        managed = False
        db_table = 'admin'


class Bill(models.Model):
    aid = models.ForeignKey(Admin, models.DO_NOTHING, db_column='aid')
    uid = models.ForeignKey('User', models.DO_NOTHING, db_column='uid')
    units = models.IntegerField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10)
    bdate = models.DateField()
    ddate = models.DateField()

    class Meta:
        managed = False
        db_table = 'bill'


class Complaint(models.Model):
    uid = models.ForeignKey('User', models.DO_NOTHING, db_column='uid')
    aid = models.ForeignKey(Admin, models.DO_NOTHING, db_column='aid')
    complaint = models.CharField(max_length=140)
    status = models.CharField(max_length=40)

    class Meta:
        managed = False
        db_table = 'complaint'


class Transaction(models.Model):
    bid = models.ForeignKey(Bill, models.DO_NOTHING, db_column='bid')
    payable = models.DecimalField(max_digits=10, decimal_places=2)
    pdate = models.DateField(blank=True, null=True)
    status = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'transaction'


class Unitsrate(models.Model):
    sno = models.IntegerField(blank=True, null=True)
    twohundred = models.IntegerField()
    fivehundred = models.IntegerField()
    thousand = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'unitsrate'


class User(models.Model):
    name = models.CharField(max_length=40)
    email = models.CharField(max_length=40)
    phone = models.IntegerField()
    pass_field = models.CharField(db_column='pass', max_length=20)  # Field renamed because it was a Python reserved word.
    address = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'user'
