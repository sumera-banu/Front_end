from django.contrib import admin

from ap2.models import Admin, User,Bill,Complaint,Transaction,Unitsrate



# Register your models here.
#admin.site.register(Admin)
@admin.register(Admin)
class Admin(admin.ModelAdmin):
    list_display=('name','email','pass_field')
    ordering=('name',)
    search_fields=('name',)

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = [field.name for field in User._meta.fields]
    ordering=('id',)
    search_fields=('name',)
    

@admin.register(Bill)
class BillAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Bill._meta.fields]
    ordering=('id',)
    

@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Complaint._meta.fields]
    ordering=('id',)
    

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Transaction._meta.fields]
    ordering=('id',)