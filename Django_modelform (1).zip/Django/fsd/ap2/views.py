from django.http import HttpResponse
from django.shortcuts import render

from ap2.models import Dopayment

# Create your views here.
def add_amount(request):
    if request.method=="POST":
        form=Dopayment(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("<h1>successfull</h1>")
        else:
            return HttpResponse("<h1>unsuccessfull</h1>")
    else:
        form=Dopayment()
        return render(request,"add_amount.html",{"form":form})
